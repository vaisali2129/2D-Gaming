## lesson_03

### Purpose

